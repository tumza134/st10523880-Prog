/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tumelopart1;

/**
 *
 * @author Student
 */
public class sendmessage {
    
}


public class Message {

    // Menu choices used by sentMessage()
    public static final int SEND = 1;
    public static final int DISCARD = 2;
    public static final int STORE = 3;

    public static final int MAX_LENGTH = 250;
    public static final int MAX_ID_LENGTH = 10;

    private static final SecureRandom RANDOM = new SecureRandom();

    // All messages sent while the program is running
    private static final List<Message> SENT_MESSAGES = new ArrayList<>();

    // Where storeMessage() writes the JSON
    private static String storagePath = "messages.json";

    private final String messageID;
    private final int numMessagesSent;
    private final String recipient;
    private final String message;
    private final String messageHash;

    /** Normal constructor: the ID is random and the number is auto-incremented. */
    public Message(String recipient, String message) {
        this(generateMessageID(), SENT_MESSAGES.size(), recipient, message);
    }

    /** Constructor that lets the caller supply the ID and number (used for unit tests). */
    public Message(String messageID, int numMessagesSent, String recipient, String message) {
        this.messageID = messageID;
        this.numMessagesSent = numMessagesSent;
        this.recipient = recipient;
        this.message = message;
        this.messageHash = createMessageHash();
    }

    // ---------------------------------------------------------------- getters

    public String getMessageID() { return messageID; }
    public int getNumMessagesSent() { return numMessagesSent; }
    public String getRecipient() { return recipient; }
    public String getMessage() { return message; }
    public String getMessageHash() { return messageHash; }

    // ---------------------------------------------------------- required methods

    /** Generates a random ten-digit message ID (leading zeros are allowed). */
    public static String generateMessageID() {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < MAX_ID_LENGTH; i++) {
            sb.append(RANDOM.nextInt(10));
        }
        return sb.toString();
    }

    /** Text shown/tested when an ID has been created. */
    public String describeMessageID() {
        return "Message ID generated: " + messageID;
    }

    /** Ensures that the message ID is not more than ten characters. */
    public boolean checkMessageID() {
        return messageID != null
                && !messageID.isEmpty()
                && messageID.length() <= MAX_ID_LENGTH;
    }

    /**
     * Ensures that the recipient number has an international code and is a valid
     * length. Re-uses the Part 1 cell number check.
     */
    public String checkRecipientCell() {
        if (recipient != null && TumeloPart1.checkCellPhoneNumber(recipient)) {
            return "Cell phone number successfully captured.";
        }
        return "Cell phone number is incorrectly formatted or does not contain an "
                + "international code. Please correct the number and try again.";
    }

    /** Checks the 250 character limit. */
    public static String checkMessageLength(String text) {
        int length = (text == null) ? 0 : text.length();
        if (length <= MAX_LENGTH) {
            return "Message ready to send.";
        }
        return "Message exceeds " + MAX_LENGTH + " characters by " + (length - MAX_LENGTH)
                + "; please reduce the size.";
    }

    /** Builds the hash: first two ID digits : message number : FIRSTWORDLASTWORD. */
    public String createMessageHash() {
        String idPart = (messageID == null) ? "" : messageID.substring(0, Math.min(2, messageID.length()));

        String[] words = (message == null) ? new String[0] : message.trim().split("\\s+");
        String first = "";
        String last = "";
        if (words.length > 0) {
            first = stripPunctuation(words[0]);
            last = stripPunctuation(words[words.length - 1]);
        }
        return (idPart + ":" + numMessagesSent + ":" + first + last).toUpperCase();
    }

    /**
     * Carries out what the user chose to do with the message.
     * 1 = send, 2 = disregard, 3 = store.
     */
    public String sentMessage(int choice) {
        switch (choice) {
            case SEND:
                SENT_MESSAGES.add(this);
                return "Message successfully sent.";
            case DISCARD:
                return "Press 0 to delete the message.";
            case STORE:
                return storeMessage() ? "Message successfully stored."
                                      : "Message could not be stored.";
            default:
                return "Invalid option.";
        }
    }

    /** Returns every message sent while the program is running. */
    public static String printMessages() {
        if (SENT_MESSAGES.isEmpty()) {
            return "No messages have been sent.";
        }
        StringBuilder sb = new StringBuilder();
        for (Message m : SENT_MESSAGES) {
            sb.append(m.getDetails()).append(System.lineSeparator());
        }
        return sb.toString().trim();
    }

    /** Returns the total number of messages sent. */
    public static int returnTotalMessages() {
        return SENT_MESSAGES.size();
    }

    /**
     * Stores this message in a JSON file. Earlier stored messages in the file
     * are kept. Returns true if the message was written.
     */
    public boolean storeMessage() {
        Path path = Paths.get(storagePath);
        try {
            String existing = "";
            if (Files.exists(path)) {
                existing = new String(Files.readAllBytes(path), StandardCharsets.UTF_8).trim();
            }

            String entry = toJson();
            String output;
            if (existing.startsWith("[") && existing.endsWith("]")) {
                String inner = existing.substring(1, existing.length() - 1).trim();
                output = inner.isEmpty()
                        ? "[\n" + entry + "\n]"
                        : "[\n" + inner + ",\n" + entry + "\n]";
            } else {
                output = "[\n" + entry + "\n]";
            }
            Files.write(path, output.getBytes(StandardCharsets.UTF_8));
            return true;
        } catch (IOException e) {
            return false;
        }
    }

    // ------------------------------------------------------------------ helpers

    /** Message ID, Message Hash, Recipient, Message - in that order. */
    public String getDetails() {
        return "Message ID: " + messageID
                + " | Message Hash: " + messageHash
                + " | Recipient: " + recipient
                + " | Message: " + message;
    }

    public String toJson() {
        return "  {\n"
                + "    \"messageID\": \"" + escapeJson(messageID) + "\",\n"
                + "    \"numMessagesSent\": " + numMessagesSent + ",\n"
                + "    \"recipient\": \"" + escapeJson(recipient) + "\",\n"
                + "    \"message\": \"" + escapeJson(message) + "\",\n"
                + "    \"messageHash\": \"" + escapeJson(messageHash) + "\"\n"
                + "  }";
    }

    public static void setStoragePath(String path) {
        storagePath = path;
    }

    /** Clears the sent message list (used by unit tests). */
    public static void resetMessages() {
        SENT_MESSAGES.clear();
    }

    private static String stripPunctuation(String word) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < word.length(); i++) {
            char ch = word.charAt(i);
            if (Character.isLetterOrDigit(ch)) {
                sb.append(ch);
            }
        }
        return sb.toString();
    }

    private static String escapeJson(String text) {
        if (text == null) {
            return "";
        }
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < text.length(); i++) {
            char ch = text.charAt(i);
            switch (ch) {
                case '"':  sb.append("\\\""); break;
                case '\\': sb.append("\\\\"); break;
                case '\n': sb.append("\\n"); break;
                case '\r': sb.append("\\r"); break;
                case '\t': sb.append("\\t"); break;
                default:
                    if (ch < 0x20) {
                        sb.append(String.format("\\u%04x", (int) ch));
                    } else {
                        sb.append(ch);
                    }
            }
        }
        return sb.toString();
    }
}
