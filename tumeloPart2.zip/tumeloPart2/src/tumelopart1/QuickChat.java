/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tumelopart1;


 
public class QuickChat {
    
}


/** Part 2 - the QuickChat menu. Only reached after a successful login. */
public class QuickChat {

    public static void run(Scanner input) {
        System.out.println();
        System.out.println("Welcome to QuickChat.");

        boolean running = true;
        while (running) {
            System.out.println();
            System.out.println("Please choose an option:");
            System.out.println("1) Send Messages");
            System.out.println("2) Show recently sent messages");
            System.out.println("3) Quit");
            System.out.print("Option: ");

            if (!input.hasNextLine()) {
                return;
            }
            String choice = input.nextLine().trim();

            switch (choice) {
                case "1":
                    sendMessages(input);
                    break;
                case "2":
                    System.out.println("Coming Soon.");
                    break;
                case "3":
                    System.out.println("Goodbye.");
                    running = false;
                    break;
                default:
                    System.out.println("Invalid option. Please enter 1, 2 or 3.");
            }
        }
    }

    private static void sendMessages(Scanner input) {
        int howMany = readPositiveInt(input, "How many messages would you like to enter? ");
        if (howMany < 0) {
            return;
        }

        for (int i = 1; i <= howMany; i++) {
            System.out.println();
            System.out.println("--- Message " + i + " of " + howMany + " ---");

            String recipient = readRecipient(input);
            if (recipient == null) {
                return;
            }
            String text = readMessageText(input);
            if (text == null) {
                return;
            }

            Message msg = new Message(recipient, text);
            System.out.println(msg.describeMessageID());

            int option = readSendOption(input);
            if (option < 0) {
                return;
            }

            String result = msg.sentMessage(option);
            System.out.println(result);

            if (option == Message.SEND) {
                System.out.println(msg.getDetails());
            } else if (option == Message.DISCARD) {
                while (true) {
                    if (!input.hasNextLine()) {
                        return;
                    }
                    if (input.nextLine().trim().equals("0")) {
                        System.out.println("Message deleted.");
                        break;
                    }
                    System.out.println("Press 0 to delete the message.");
                }
            }
        }

        System.out.println();
        System.out.println("Total messages sent: " + Message.returnTotalMessages());
    }

    private static String readRecipient(Scanner input) {
        while (true) {
            System.out.print("Enter the recipient's cell number (with international code): ");
            if (!input.hasNextLine()) {
                return null;
            }
            String number = input.nextLine().trim();
            Message check = new Message(Message.generateMessageID(), 0, number, "");
            String result = check.checkRecipientCell();
            System.out.println(result);
            if (result.equals("Cell phone number successfully captured.")) {
                return number;
            }
        }
    }

    private static String readMessageText(Scanner input) {
        while (true) {
            System.out.print("Enter your message: ");
            if (!input.hasNextLine()) {
                return null;
            }
            String text = input.nextLine();
            if (text.trim().isEmpty()) {
                System.out.println("A message cannot be empty.");
            } else if (text.length() > Message.MAX_LENGTH) {
                System.out.println("Please enter a message of less than 250 characters.");
            } else {
                System.out.println("Message sent");
                return text;
            }
        }
    }

    private static int readSendOption(Scanner input) {
        while (true) {
            System.out.println("What would you like to do with this message?");
            System.out.println("1) Send Message");
            System.out.println("2) Disregard Message");
            System.out.println("3) Store Message to send later");
            System.out.print("Option: ");
            if (!input.hasNextLine()) {
                return -1;
            }
            String choice = input.nextLine().trim();
            if (choice.equals("1") || choice.equals("2") || choice.equals("3")) {
                return Integer.parseInt(choice);
            }
            System.out.println("Invalid option. Please enter 1, 2 or 3.");
        }
    }

    private static int readPositiveInt(Scanner input, String prompt) {
        while (true) {
            System.out.print(prompt);
            if (!input.hasNextLine()) {
                return -1;
            }
            try {
                int value = Integer.parseInt(input.nextLine().trim());
                if (value > 0) {
                    return value;
                }
            } catch (NumberFormatException e) {
                // fall through to the message below
            }
            System.out.println("Please enter a whole number greater than 0.");
        }
    }
}

