package tumelopart1;

import java.util.Scanner;
import org.junit.Test;
import static org.junit.Assert.*;

public class TumeloPart1Test {

    // Test username validation
    @Test
    public void testCheckUserName() {

        assertTrue(
                "Valid username should contain an underscore and be 5 characters or less",
                TumeloPart1.checkUserName("tum_1")
        );

        assertFalse(
                "Username without an underscore should be invalid",
                TumeloPart1.checkUserName("tumelo")
        );

        assertFalse(
                "Username longer than 5 characters should be invalid",
                TumeloPart1.checkUserName("tumelo_1")
        );
    }

    // Test password validation
    @Test
    public void testCheckPassword() {

        assertTrue(
                "Valid password should contain 8+ characters, capital letter, number and special character",
                TumeloPart1.checkPassword("Password1!")
        );

        assertFalse(
                "Password without a capital letter should be invalid",
                TumeloPart1.checkPassword("password1!")
        );

        assertFalse(
                "Password without a number should be invalid",
                TumeloPart1.checkPassword("Password!")
        );

        assertFalse(
                "Password without a special character should be invalid",
                TumeloPart1.checkPassword("Password1")
        );

        assertFalse(
                "Password shorter than 8 characters should be invalid",
                TumeloPart1.checkPassword("Pass1!")
        );
    }

    // Test cell phone number validation
    @Test
    public void testCheckCellPhoneNumber() {

        assertTrue(
                "Phone number with international code should be valid",
                TumeloPart1.checkCellPhoneNumber("+27821234567")
        );

        assertFalse(
                "Phone number without international code should be invalid",
                TumeloPart1.checkCellPhoneNumber("0821234567")
        );

        assertFalse(
                "Phone number longer than 13 characters should be invalid",
                TumeloPart1.checkCellPhoneNumber("+27821234567890")
        );
    }

    // Test successful login
    @Test
    public void testSuccessfulLogin() {

        TumeloPart1 user = new TumeloPart1();

        user.name = "Tumelo";
        user.surname = "Mokoena";
        user.username = "tum_1";
        user.password = "Password1!";
        user.cellPhoneNumber = "+27821234567";

        Scanner input = new Scanner(
                "tum_1\nPassword1!\n"
        );

        boolean result = login.loginUser(input, user);

        assertTrue(
                "Login should be successful when username and password are correct",
                result
        );
    }

    // Test incorrect login details followed by correct details
    @Test
    public void testLoginWithIncorrectDetails() {

        TumeloPart1 user = new TumeloPart1();

        user.name = "Tumelo";
        user.surname = "Mokoena";
        user.username = "tum_1";
        user.password = "Password1!";
        user.cellPhoneNumber = "+27821234567";

        Scanner input = new Scanner(
                "wrong\nwrong\n"
                + "tum_1\nPassword1!\n"
        );

        boolean result = login.loginUser(input, user);

        assertTrue(
                "Login should eventually be successful after correct details are entered",
                result
        );
    }

    // Test login status messages
    @Test
    public void testReturnLoginStatus() {

        TumeloPart1 user = new TumeloPart1();

        user.name = "Tumelo";
        user.surname = "Mokoena";
        user.username = "tum_1";
        user.password = "Password1!";

        String successMessage =
                login.returnLoginStatus(user, true);

        assertEquals(
                "Welcome Tumelo, Mokoena it is great to see you again.",
                successMessage
        );

        String failureMessage =
                login.returnLoginStatus(user, false);

        assertEquals(
                "Username or password is incorrect, please try again.",
                failureMessage
        );
    }
}